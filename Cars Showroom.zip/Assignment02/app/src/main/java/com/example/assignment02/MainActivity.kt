package com.example.assignment02

import android.content.Context
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.novels.Article

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
       val recyclerView:RecyclerView = findViewById(R.id.recyclerview)
        val adapter = ArticlesAdapter(getArticles())

        recyclerView.adapter=adapter
        recyclerView.layoutManager=LinearLayoutManager(this)



    }

    fun getArticles(): List<Article> {
        val articles=ArrayList<Article>()
        articles.add(
            Article(
            title = "BMW M Series M1",
            image = R.drawable.m1,
            details = "BMW M1\" The BMW 1 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 1 Series:\n" +
                    "\n" +
                    "Features:\n" +
                    "\n" +
                    " Engine Options:The 1 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                    "\n" +
                    " Transmission:Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                    "\n" +
                    " Rear-Wheel Drive:Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                    "\n" +
                    " Interior Quality:High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            ))



        articles.add(
            Article(
                title = "BMW M Series M2",
                image = R.drawable.m2,
                details = "BMW M2\" The BMW 2 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 2 Series:\n" +
                        "\n" +
                        "Features:\n" +
                        "\n" +
                        " Engine Options: The 2 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive: Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality: High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )

        articles.add(
            Article(
                title = "BMW M Series M3",
                image = R.drawable.m3,
                details = "BMW M3\" The BMW 3 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 3 Series:\n" +
                        "\n" +
                        "Features:\n" +
                        "\n" +
                        " Engine Options:**The 3 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: **Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive:**Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality:**High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )
        articles.add(
            Article(
                title = "BMW M Series M4",
                image = R.drawable.m4,
                details = "BMW M4\" The BMW 4 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 4 Series:\n" +
                        "\n" +
                        "### Features:\n" +
                        "\n" +
                        " Engine Options:**The 4 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: **Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive:**Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality:**High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )

        articles.add(
            Article(
                title = "BMW M Series M5",
                image = R.drawable.m5,
                details = "BMW M5\" The BMW 5 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 5 Series:\n" +
                        "\n" +
                        " Features:\n" +
                        "\n" +
                        " Engine Options:**The 5 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: **Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive:**Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality:**High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )


        articles.add(
            Article(
                title = "BMW M Series M7",
                image = R.drawable.m7,
                details = "BMW M7\" The BMW 7 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 7 Series:\n" +
                        "\n" +
                        " Features:\n" +
                        "\n" +
                        " Engine Options:The 7 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive:Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality:High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )
        articles.add(
            Article(
                title = "BMW M Series M8",
                image = R.drawable.m8,
                details = "BMW M8\" The BMW 8 Series is a compact luxury car that combines sporty performance with premium features. Here are some key features typically found in the BMW 8 Series:\n" +
                        "\n" +
                        " Features:\n" +
                        "\n" +
                        " Engine Options: The 8 Series offers a range of powerful engines, including turbocharged options for enhanced performance and efficiency.\n" +
                        "\n" +
                        " Transmission: Most models come with an 8-speed automatic transmission for smooth shifting and responsiveness..\n" +
                        "\n" +
                        " Rear-Wheel Drive: Many versions feature BMW's traditional rear-wheel-drive layout, providing excellent handling dynamics\n" +
                        "\n" +
                        " Interior Quality: High-quality materials and finishes create a luxurious cabin experience, with options for leather upholstery and customizable ambient lighting.\n"

            )
        )

        return articles
    }
}
